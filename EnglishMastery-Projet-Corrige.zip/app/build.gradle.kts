plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.evotrix.englishmastery"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.evotrix.englishmastery"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
}
