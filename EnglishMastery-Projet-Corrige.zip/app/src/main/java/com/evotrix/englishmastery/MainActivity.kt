package com.evotrix.englishmastery

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import android.content.Context

data class Module(val id:Int, val title:String, val subtitle:String, val file:String)

class MainActivity : Activity() {
    private val modules = listOf(
        Module(0,"Identité, méthode et architecture","Vue d’ensemble du programme","english-mastery-module-0.html"),
        Module(1,"Introduction et test de niveau","Méthode d’utilisation et test A0 à C2","english-mastery-module-1.html"),
        Module(2,"Niveau 0 — Partie 1","Alphabet, prononciation, salutations et présentations","english-mastery-module-2.html"),
        Module(3,"Niveau 0 — Partie 2","Nombres, dates, heure, famille et expressions","english-mastery-module-3.html"),
        Module(4,"Niveau 1 — Partie 1","Pronoms, TO BE, TO HAVE, articles et possessifs","english-mastery-module-4.html"),
        Module(5,"Niveau 1 — Partie 2","Simple Present, pluriels, questions et vocabulaire","english-mastery-module-5.html"),
        Module(6,"Niveau 2 — Partie 1","Present Continuous, Past, futur et can/can't","english-mastery-module-6.html"),
        Module(7,"Niveau 2 — Partie 2","Should, must, have to, comparatifs et superlatifs","english-mastery-module-7.html"),
        Module(8,"Niveau 2 — Partie 3","Quantités, phrasal verbs et situations réelles","english-mastery-module-8.html"),
        Module(9,"Niveau 3 — Partie 1","Present Perfect, Past Continuous et Past Perfect","english-mastery-module-9.html"),
        Module(10,"Niveau 3 — Partie 2","Futur, conditionnels, modaux et relatives","english-mastery-module-10.html")
    )
    private lateinit var root: LinearLayout
    private lateinit var prefs: android.content.SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("progress", Context.MODE_PRIVATE)
        showHome()
    }

    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()

    private fun text(t:String, size:Float, color:Int, bold:Boolean=false): TextView {
        val x=TextView(this); x.text=t; x.textSize=size; x.setTextColor(color)
        x.setPadding(dp(4),dp(4),dp(4),dp(4))
        if(bold) x.setTypeface(null, android.graphics.Typeface.BOLD)
        return x
    }

    private fun base(): LinearLayout {
        val scroll=ScrollView(this)
        root=LinearLayout(this); root.orientation=LinearLayout.VERTICAL
        root.setPadding(dp(18),dp(16),dp(18),dp(24)); root.setBackgroundColor(Color.rgb(247,248,252))
        scroll.addView(root); setContentView(scroll)
        return root
    }

    private fun showHome() {
        val r=base()
        val header=LinearLayout(this); header.orientation=LinearLayout.VERTICAL
        header.setPadding(dp(20),dp(28),dp(20),dp(26)); header.setBackgroundColor(Color.rgb(11,26,58))
        val title=text("ENGLISH MASTERY",30,Color.WHITE,true); title.gravity=Gravity.CENTER
        val sub=text("De zéro à une communication anglaise fluide et professionnelle",15,Color.rgb(217,184,102)); sub.gravity=Gravity.CENTER
        header.addView(title); header.addView(sub); r.addView(header)
        val done=modules.count{prefs.getBoolean("done_${it.id}",false)}
        val pct=done*100/modules.size
        val p=text("Progression : $done / ${modules.size} modules  •  $pct%",17,Color.rgb(11,26,58),true)
        p.setPadding(0,dp(20),0,dp(10)); r.addView(p)
        val bar=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal)
        bar.max=100; bar.progress=pct; r.addView(bar)
        val intro=text("Ton parcours",22,Color.rgb(11,26,58),true); intro.setPadding(0,dp(22),0,dp(10)); r.addView(intro)
        modules.forEach { m ->
            val b=Button(this)
            val check=if(prefs.getBoolean("done_${m.id}",false)) "✓ " else ""
            b.text="${check}Module ${m.id} — ${m.title}\n${m.subtitle}"
            b.textSize=14f; b.setTextColor(Color.rgb(11,26,58)); b.setGravity(Gravity.START or Gravity.CENTER_VERTICAL)
            b.setPadding(dp(16),dp(12),dp(12),dp(12))
            b.setOnClickListener { openModule(m) }
            val lp=LinearLayout.LayoutParams(-1,dp(76)); lp.setMargins(0,0,0,dp(10)); r.addView(b,lp)
        }
        val info=text("Mode hors ligne • Contenu inclus dans l’application",13,Color.rgb(91,101,128)); info.gravity=Gravity.CENTER; info.setPadding(0,dp(20),0,0); r.addView(info)
    }

    private fun openModule(m:Module) {
        val layout=LinearLayout(this); layout.orientation=LinearLayout.VERTICAL; layout.setBackgroundColor(Color.WHITE)
        val top=LinearLayout(this); top.setPadding(dp(8),dp(6),dp(8),dp(6)); top.setBackgroundColor(Color.rgb(11,26,58))
        val back=Button(this); back.text="‹"; back.setTextColor(Color.WHITE); back.setBackgroundColor(Color.TRANSPARENT)
        back.setOnClickListener { showHome() }
        val label=text("Module ${m.id} — ${m.title}",17,Color.WHITE,true); label.gravity=Gravity.CENTER_VERTICAL
        top.addView(back,LinearLayout.LayoutParams(dp(55),dp(50))); top.addView(label,LinearLayout.LayoutParams(0,dp(50),1f))
        layout.addView(top)
        val web=WebView(this)
        web.settings.javaScriptEnabled=true; web.settings.domStorageEnabled=true
        web.settings.allowFileAccess=true; web.webViewClient=WebViewClient()
        web.loadUrl("file:///android_asset/english/${m.file}")
        layout.addView(web,LinearLayout.LayoutParams(-1,0,1f))
        val complete=Button(this)
        complete.text=if(prefs.getBoolean("done_${m.id}",false)) "✓ Module terminé" else "Marquer le module comme terminé"
        complete.setOnClickListener {
            prefs.edit().putBoolean("done_${m.id}",true).apply()
            complete.text="✓ Module terminé"
        }
        layout.addView(complete)
        setContentView(layout)
    }

    override fun onBackPressed() {
        showHome()
    }
}
